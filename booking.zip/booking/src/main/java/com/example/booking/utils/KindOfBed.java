package com.example.booking.utils;

public enum  KindOfBed {
    SINGLESIZE(0),
    MATRIMONIAL(1),
    KINGSIZE(2);

    private int id;

    KindOfBed() {
    }

    KindOfBed(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
