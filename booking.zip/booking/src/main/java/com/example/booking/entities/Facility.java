package com.example.booking.entities;


import com.example.booking.utils.FacilityType;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "facilities")
public class Facility {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "svg")
    private String SVG;

    @Column(name = "facility_type")
    private FacilityType facilityType;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "hotels_facilities",
                joinColumns = @JoinColumn(name = "facility_id"),
                inverseJoinColumns = @JoinColumn(name = "hotel_id"))
    private List<Hotel> hotelList;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name =  "room_facilities",
                joinColumns = @JoinColumn(name = "facility_id"),
                inverseJoinColumns = @JoinColumn(name = "room_id"))
    private List<Room> roomList;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "offer_facilities",
               joinColumns = @JoinColumn(name = "facility_id"),
               inverseJoinColumns = @JoinColumn(name = "offer_id"))
    private List<Offer> offerList;

    public Facility() {
    }

    public Facility(String SVG, FacilityType facilityType, List<Hotel> hotelList, List<Room> roomList, List<Offer> offerList) {
        this.SVG = SVG;
        this.facilityType = facilityType;
        this.hotelList = hotelList;
        this.roomList = roomList;
        this.offerList = offerList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSVG() {
        return SVG;
    }

    public void setSVG(String SVG) {
        this.SVG = SVG;
    }

    public FacilityType getFacilityType() {
        return facilityType;
    }

    public void setFacilityType(FacilityType facilityType) {
        this.facilityType = facilityType;
    }

    public List<Hotel> getHotelList() {
        return hotelList;
    }

    public void setHotelList(List<Hotel> hotelList) {
        this.hotelList = hotelList;
    }

    public List<Room> getRoomList() {
        return roomList;
    }

    public void setRoomList(List<Room> roomList) {
        this.roomList = roomList;
    }

    public List<Offer> getOfferList() {
        return offerList;
    }

    public void setOfferList(List<Offer> offerList) {
        this.offerList = offerList;
    }
}
