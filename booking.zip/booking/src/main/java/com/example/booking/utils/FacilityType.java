package com.example.booking.utils;

public enum FacilityType {

    WI_FI(0),
    MASSAGE(1),
    BREAKFAST(2),
    OlED_TV(3);

    private int id;

    FacilityType() {
    }

    FacilityType(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
