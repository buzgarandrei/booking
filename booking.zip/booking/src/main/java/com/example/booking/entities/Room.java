package com.example.booking.entities;


import com.example.booking.utils.KindOfBed;

import javax.persistence.*;

@Entity
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private int number;

    @Column(name = "number_of_beds")
    private int numberOfBeds;

    @Column(name = "kind_of_beds")
    private KindOfBed kindOfBed;

    @Column
    private boolean reserved;

    public Room() {
    }

    public Room(int number, int numberOfBeds, KindOfBed kindOfBed, boolean reserved) {
        this.number = number;
        this.numberOfBeds = numberOfBeds;
        this.kindOfBed = kindOfBed;
        this.reserved = reserved;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumberOfBeds() {
        return numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;
    }

    public KindOfBed getKindOfBed() {
        return kindOfBed;
    }

    public void setKindOfBed(KindOfBed kindOfBed) {
        this.kindOfBed = kindOfBed;
    }

    public boolean isReserved() {
        return reserved;
    }

    public void setReserved(boolean reserved) {
        this.reserved = reserved;
    }
}
