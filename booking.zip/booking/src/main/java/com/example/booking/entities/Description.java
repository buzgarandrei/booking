package com.example.booking.entities;

import com.example.booking.utils.Language;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "descriptions")
public class Description {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private Language language;

    @Column
    private String text;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "hotels_descriptions",
                joinColumns = @JoinColumn(name = "description_id"),
                inverseJoinColumns = @JoinColumn(name = "hotel_id"))
    private List<Hotel> hotelList;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "rooms_descriptions",
                joinColumns = @JoinColumn(name = "description_id"),
                inverseJoinColumns = @JoinColumn(name = "room_id"))
    private List<Room> roomList;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "offers_descriptions",
                joinColumns = @JoinColumn(name = "description_id"),
                inverseJoinColumns = @JoinColumn(name = "offer_id"))
    private List<Offer> offerList;

    public Description() {
    }

    public Description(Language language, String text, List<Hotel> hotelList, List<Room> roomList, List<Offer> offerList) {
        this.language = language;
        this.text = text;
        this.hotelList = hotelList;
        this.roomList = roomList;
        this.offerList = offerList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public List<Hotel> getHotelList() {
        return hotelList;
    }

    public void setHotelList(List<Hotel> hotelList) {
        this.hotelList = hotelList;
    }

    public List<Room> getRoomList() {
        return roomList;
    }

    public void setRoomList(List<Room> roomList) {
        this.roomList = roomList;
    }

    public List<Offer> getOfferList() {
        return offerList;
    }

    public void setOfferList(List<Offer> offerList) {
        this.offerList = offerList;
    }
}
